If you are unable to open the gimagex.chm help file then try the following:

1. Right-click the gimagex.chm and select Properties.
2. Click Unblock.
3. Click OK.